<?PHP


class reclam{


private $mail;
private $ad;
private $tel;
private $num;
private $descr;
Private $Etat;
	function __construct($mail,$ad,$tel,$num,$descr){

		$this->mail=$mail;

		$this->ad=$ad;
		$this->tel=$tel;

		$this->num=$num;
		$this->descr=$descr;

	}



	function getmail(){
		return $this->mail;
	}

	function getad(){
		return $this->ad;
	}
	function gettel(){
		return $this->tel;
	}

	function getnum(){
		return $this->num;
	}
	function getdescr(){
		return $this->descr;
	}
	function getEtat(){
		return $this->Etat;
	}




	function setnum($num){
		$this->num=$num;
	}
	function setdescr($descr){
		$this->descr=$descr;
	}
	function setEtat($Etat){
		$this->Etat=$Etat;
	}

	function setad($ad){
		$this->ad=$ad;
	}

	function setmail($mail){
		$this->mail=$mail;
	}
	function settel($tel){
		$this->tel=$tel;
	}

}

?>
