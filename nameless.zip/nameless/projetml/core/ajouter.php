<?PHP

include 'reclamr.php';



include_once ('../config/config.php');
$recl= new reclam($_POST['email'],$_POST['ad'],$_POST['numtel'],$_POST['num'],$_POST['descr']);
//var_dump($_POST);
$reclamr1=new reclamr();
$reclamr1->ajoutereclamr($recl);



echo "*ergtr";
require '../PHPMailer/PHPMailer.php';
require '../PHPMailer/Exception.php';
require '../PHPMailer/OAuth.php';
require '../PHPMailer/POP3.php';
require '../PHPMailer/SMTP.php';

$mail = new PHPMailer\PHPMailer\PHPMailer();;
// SMTP configuration
/*if (isset($_POST['name'])&&isset($_POST['mdp']) && isset($_POST['email'])&& isset($_POST['to']) &&isset($_POST['sujet']) && isset($_POST['mc']) )
{*/
	/*$nom= 'khalil';// $_POST['name'];
	$prenom= 'khalil13031997'; //$_POST['mdp'];
	$numero= 'mohamedkhalil.benkhedher@esprit.tn';//$_POST['email'];

	$numero2='mohamedkhalil.benkhedher@esprit.tn';//$_POST['to'];
	 $numero3='heloooo';  //$_POST['mc'];*/
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username =  'info.nexshop@gmail.com'; //$numero;
$mail->Password ='nexshop98@';// $prenom;
$mail->SMTPSecure = 'tls';
$mail->Port = 587;
$mail->setFrom('info.nexshop@gmail.com','NexShop Info');


// Add a recipient
$mail->addAddress($_POST['email']);


// Add cc or bcc
/*$mail->addCC('');
$mail->addBCC('bcc@example.com');*/

// Email subject
$mail->Subject ='Réclamation NexShop';

// Set email format to HTML
$mail->isHTML(true);

// Email body content
//$mailContent = 'gstrhythfg';
$mail->Body = 'Votre réclamation a bien été enregistré';
//header('Location: checkout.html');

// Send email
if(!$mail->send()){
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;

}else{
    echo 'Message has been sent';
    header("Location:../views/index.php");
}

//}

?>
