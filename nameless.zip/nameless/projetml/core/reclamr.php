<?PHP

include "reclam.php";
include "C:/wamp/www/nameless/projetml/config/config.php";



class reclamr {


	function ajoutereclamr($reclam){
		$sql="INSERT INTO  reclam (email,numtel,num,ad,descr,id,Etat) VALUES (:mail,:tel,:num,:ad,:descr,0,:Etat)" ;
        $db =config::getConnexion();
        $req=$db->prepare($sql);


        $mail=$reclam->getmail();
        $ad=$reclam->getad();
        $num=$reclam->getnum();
        $descr=$reclam->getdescr();
        $tel=$reclam->gettel();
        $Etat=$reclam->getEtat();


		$req->bindValue(':mail',$mail);
		$req->bindValue(':ad',$ad);
		$req->bindValue(':tel',$tel);
		$req->bindValue(':num',$num);
		$req->bindValue(':descr',$descr);
    $req->bindValue(':Etat','non traite');
		$req->execute();


	}

	function affichereclamr(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql=" SELECT * From reclam";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function supprimer($id){
		$sql="DELETE FROM reclam where id = :id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifiereclamr($reclam,$nom){
		$sql="UPDATE reclam SET ad=:ad,tel=:tel,num=:num,descr=:descr,Etat=:Etat,mail=:mail WHERE tel=:tel";

		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);

        $req=$db->prepare($sql);

        $mail=$reclam->getmail();
        $ad=$reclam->getad();
        $num=$reclam->getnum();
        $tel=$reclam->gettel();
        $Etat=$reclam->getEtat();



		$req->bindValue(':mail',$mail);
		$req->bindValue(':ad',$ad);
		$req->bindValue(':tel',$tel);
		$req->bindValue(':num',$num);
		$req->bindValue(':descr',$descr);
    $req->bindValue(':Etat','non traite');

            $s=$req->execute();

           header('Location: index.html');



	}
	function recuperereclamr($nom){
		$sql="SELECT * from reclam where tel=$tel";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}


}

?>
