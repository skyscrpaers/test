<?PHP
include "C:/wamp/www/nameless/projetml/core/reclamr.php";
$reclam=new reclamr();
if (isset($_POST["id"])){
	$reclam->supprimer($_POST["id"]);
		header('Location:product-cart.php');
}

?>
